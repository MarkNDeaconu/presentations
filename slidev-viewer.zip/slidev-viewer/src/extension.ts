import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
  const disposable = vscode.commands.registerCommand('slidevViewer.open', () => {
    const panel = vscode.window.createWebviewPanel(
      'slidevViewer', // Identifies the type of the webview
      'Slidev Viewer', // Title of the panel
      vscode.ViewColumn.One, // Editor column to show the new webview panel in
      {
        enableScripts: true,
      }
    );

    panel.webview.html = getWebviewContent();
  });

  context.subscriptions.push(disposable);
}

export function deactivate() {}

function getWebviewContent() {
  return `
    <!DOCTYPE html>
    <html lang="en">
    <body style="margin:0;padding:0;height:100vh;">
      <iframe src="http://localhost:3030" width="100%" height="100%" frameborder="0"></iframe>
    </body>
    </html>
  `;
}

